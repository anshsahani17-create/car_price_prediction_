# Revale — Used Car Resale Value Website

A minimal, animated Flask website that estimates an indicative used-car resale value from car make/model, year, kilometres driven, fuel, transmission, ownership, engine capacity, mileage and seating.

## Features
- Responsive, minimal UI with custom car illustration and subtle scroll-linked movement.
- Scroll reveal animations and reduced-motion accessibility support.
- Optional mobile haptic feedback through `navigator.vibrate()` (only on supported devices/browsers).
- Flask JSON API and a scikit-learn Random Forest model.
- Brand/model are included as categorical features, so different models can receive different estimates.
- INR-formatted estimated price and an indicative ±10% range.
- CSV dataset included at `data/car_resale_data.csv`.

## Run locally
Requires Python 3.10+.

```bash
# 1. Extract this folder and open a terminal in it
python -m venv .venv

# macOS/Linux
source .venv/bin/activate

# Windows
# .venv\\Scripts\\activate

pip install -r requirements.txt
python app.py
```

Open the local URL shown in the terminal, usually `http://127.0.0.1:5000`.

The first run trains the model from the CSV and creates `car_resale_model.joblib`.

## Dataset caveat
The included CSV is a **synthetic demo dataset**, generated for testing the project UI and model pipeline. It is not a verified market-price dataset and must not be presented as real market evidence. Prices are stored in Indian rupees lakh units in the `selling_price_lakh` column. For credible real-world estimates, replace it with a legally obtained, cleaned dataset of actual Indian used-car transactions/listings and retrain the model.

## Files
- `app.py` — Flask routes and model training/prediction.
- `data/car_resale_data.csv` — demo training data.
- `templates/index.html` — page layout.
- `static/css/style.css` — styling and animations.
- `static/js/main.js` — interactions, scroll animation, haptic feedback, form submission.
- `requirements.txt` — Python dependencies.

## API example
`POST /api/estimate` with JSON:

```json
{
  "brand": "Maruti Suzuki",
  "model": "Swift",
  "year": 2021,
  "km_driven": 45000,
  "fuel": "Petrol",
  "transmission": "Manual",
  "owner": "First owner",
  "engine_cc": 1200,
  "mileage_kmpl": 18,
  "seats": 5
}
```

This is an educational estimate, not a guaranteed resale quote. Vehicle condition, accident history, service records, location, trim/variant, insurance and market demand are not fully represented.
