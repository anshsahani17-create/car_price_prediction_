(() => {
  const $ = (selector, root = document) => root.querySelector(selector);
  const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
  const form = $("#estimateForm");
  const brand = $("#brand");
  const model = $("#model");
  const pages = $$(".form-page");
  const error = $("#formError");
  const resultPanel = $("#resultPanel");
  const submitBtn = $("#submitBtn");
  let page = 1;

  // Reveal content as it enters the viewport.
  const revealObserver = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add("visible");
        revealObserver.unobserve(entry.target);
      }
    });
  }, { threshold: 0.12 });
  $$(".reveal").forEach(el => revealObserver.observe(el));

  // Small scroll-linked car movement, intentionally subtle.
  const hero = $("#heroVisual");
  const car = $("#heroCar");
  let scrollTicking = false;
  window.addEventListener("scroll", () => {
    if (scrollTicking || !hero || !car) return;
    scrollTicking = true;
    requestAnimationFrame(() => {
      const rect = hero.getBoundingClientRect();
      const viewport = window.innerHeight || 1;
      const progress = Math.max(-1, Math.min(1, (viewport * 0.55 - rect.top) / (viewport + rect.height)));
      const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
      if (!reduced) car.style.transform = `translate(${progress * 13}px, ${10 - progress * 13}px) rotate(${progress * -0.6}deg)`;
      scrollTicking = false;
    });
  }, { passive: true });

  // Haptic feedback is supported on some mobile browsers; gracefully ignored elsewhere.
  function haptic(pattern = 12) {
    try { if ("vibrate" in navigator) navigator.vibrate(pattern); } catch (_) {}
  }
  document.addEventListener("click", event => {
    if (event.target.closest("button, .button, .nav-cta")) haptic(8);
  });

  function showPage(next) {
    page = next;
    pages.forEach(p => p.classList.toggle("active", Number(p.dataset.page) === page));
    $("#stepLabel").textContent = page === 1 ? "01 — 02" : "02 — 02";
    $(".progress-track span").style.width = page === 1 ? "50%" : "100%";
    error.textContent = "";
    if (page === 2) haptic([10, 25, 10]);
  }
  function validatePageOne() {
    for (const name of ["brand", "model", "year", "km_driven"]) {
      const input = form.elements[name];
      if (!input || !input.checkValidity() || !input.value) {
        input?.reportValidity();
        return false;
      }
    }
    return true;
  }
  $("#nextBtn").addEventListener("click", () => {
    if (validatePageOne()) showPage(2);
  });
  $("#backBtn").addEventListener("click", () => showPage(1));

  function fillModels(selectedBrand) {
    model.innerHTML = '<option value="">Choose model</option>';
    const choices = (window.MODELS_BY_BRAND || {})[selectedBrand] || [];
    choices.forEach(name => {
      const option = document.createElement("option");
      option.value = name; option.textContent = name;
      model.appendChild(option);
    });
    model.disabled = choices.length === 0;
    if (!choices.length) model.innerHTML = '<option value="">No models found</option>';
  }
  brand.addEventListener("change", () => { fillModels(brand.value); haptic(8); });
  // Preselect first valid model after brand selection.
  model.addEventListener("change", () => haptic(6));

  function formatINR(value) {
    return new Intl.NumberFormat("en-IN", {
      style: "currency", currency: "INR", maximumFractionDigits: 0
    }).format(value);
  }

  form.addEventListener("submit", async event => {
    event.preventDefault();
    error.textContent = "";
    if (!form.reportValidity()) return;
    submitBtn.disabled = true;
    submitBtn.innerHTML = 'Calculating <span class="spinner">↻</span>';
    const payload = Object.fromEntries(new FormData(form).entries());
    try {
      const response = await fetch("/api/estimate", {
        method: "POST", headers: {"Content-Type": "application/json"},
        body: JSON.stringify(payload)
      });
      const data = await response.json();
      if (!response.ok || !data.ok) throw new Error(data.error || "Couldn't calculate this estimate.");
      $("#resultPrice").textContent = formatINR(data.price);
      $("#resultRange").textContent = `${formatINR(data.low)} to ${formatINR(data.high)}`;
      $("#resultNote").textContent = `${data.age} year(s) old. ${data.note}`;
      form.hidden = true;
      $(".form-progress").hidden = true;
      $(".progress-track").hidden = true;
      resultPanel.hidden = false;
      haptic([15, 35, 15]);
      resultPanel.scrollIntoView({behavior: "smooth", block: "center"});
    } catch (err) {
      error.textContent = err.message || "Something went wrong. Please try again.";
      haptic([35, 30, 35]);
    } finally {
      submitBtn.disabled = false;
      submitBtn.innerHTML = 'Estimate value <span>↗</span>';
    }
  });
  $("#resetBtn").addEventListener("click", () => {
    form.reset();
    form.hidden = false;
    $(".form-progress").hidden = false;
    $(".progress-track").hidden = false;
    resultPanel.hidden = true;
    fillModels(brand.value);
    showPage(1);
    $("#estimate").scrollIntoView({behavior: "smooth"});
  });
})();
